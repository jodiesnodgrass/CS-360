package com.example.project2.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface AppDao {

    // --- USER AUTHENTICATION ---

    @Insert
    void registerUser(User user); // CREATE: Saves a new user

    @Query("SELECT * FROM users WHERE username = :user AND password = :pass LIMIT 1")
    User login(String user, String pass); // READ: Checks login credentials


    // --- WEIGHT DATA (The Grid Shell) ---

    @Insert
    void insertWeight(WeightEntry entry); // CREATE: Adds an entry

    @Query("SELECT * FROM weight_entries")
    List<WeightEntry> getAllWeights(); // READ: Gets all items for the grid

    @Update
    void updateWeight(WeightEntry entry); // UPDATE: Changes existing data

    @Delete
    void deleteWeight(WeightEntry entry); // DELETE: Removes an item
}
