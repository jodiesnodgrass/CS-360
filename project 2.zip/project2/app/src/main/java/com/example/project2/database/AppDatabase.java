package com.example.project2.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// Declare which entities (tables) belong in this database
@Database(entities = {User.class, WeightEntry.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {


    public abstract AppDao appDao();

    private static AppDatabase instance;

    // Returns the same database instance every time it's called
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "user_database")
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
    }
}
