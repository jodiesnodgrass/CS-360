package com.example.project2;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project2.database.AppDatabase;
import com.example.project2.database.User;


public class RegisterActivity extends AppCompatActivity {

    // UI component declarations
    private EditText regEmail, regPassword;
    private Button signUpButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize the database shell
        db = AppDatabase.getInstance(this);

        // Link Java variables to XML layout IDs
        regEmail = findViewById(R.id.regEmail);
        regPassword = findViewById(R.id.regPassword);
        signUpButton = findViewById(R.id.signUpButton);

        // Set listener for the Sign Up action
        signUpButton.setOnClickListener(v -> {
            createNewUser();
        });
    }

    /**
     * Captures user input and performs the CREATE operation in the database.
     */
    private void createNewUser() {
        String email = regEmail.getText().toString().trim();
        String password = regPassword.getText().toString().trim();

        // Ensure the user didn't leave fields blank
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new User object and insert it via the DAO
        try {
            User newUser = new User(email, password);
            db.appDao().registerUser(newUser);

            // Inform the user and navigate back to the Login screen
            Toast.makeText(this, "Account Created! You can now log in.", Toast.LENGTH_SHORT).show();

            // finish() removes this activity from the stack and returns to MainActivity
            finish();

        } catch (Exception e) {
            // Error handling in case of database issues
            Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}

