package com.example.project2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermission extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    // Declaring UI elements
    Button buttonAllow, buttonSendTest, buttonBack;
    TextView statusText;
    EditText phoneNumberInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smspermission);

        // Linking variables to the XML layout IDs
        buttonAllow = findViewById(R.id.buttonAllow);
        buttonSendTest = findViewById(R.id.buttonSendTest);
        buttonBack = findViewById(R.id.buttonBack);
        statusText = findViewById(R.id.statusText);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);

        // Updates the UI text based on current permission status on launch
        updateStatus();

        // Trigger the system permission dialog when clicked
        buttonAllow.setOnClickListener(v -> requestSmsPermission());

        buttonSendTest.setOnClickListener(v -> {
            // Only attempt to send if the user has already clicked "Allow"
            if (hasSmsPermission()) {
                sendTestSms();
            } else {
                statusText.setText("SMS permission not granted. Cannot send notifications.");
            }
        });

        // Closes this activity and goes back to the previous screen
        buttonBack.setOnClickListener(v -> finish());
    }

    private void sendTestSms() {
        // Convert the user input to a string
        String phone = phoneNumberInput.getText().toString().trim();
        String message = "Weight Tracker: This is your test notification!";

        // Ensure the phone number field isn't empty before sending
        if (!TextUtils.isEmpty(phone)) {
            try {
                // Get SmsManager in a way that's compatible with modern Android
                SmsManager smsManager = getSystemService(SmsManager.class);
                
                if (smsManager != null) {
                    // Send the message (null parameters are for delivery reports/sent tracking)
                    smsManager.sendTextMessage(phone, null, message, null, null);
                    statusText.setText("Test SMS sent successfully to: " + phone);
                } else {
                    statusText.setText("Error: SmsManager not available.");
                }
            } catch (Exception e) {
                // Catch errors like "No SIM card" or "Airplane Mode"
                statusText.setText("Error: Could not send SMS.");
                e.printStackTrace();
            }
        } else {
            statusText.setText("Please enter a phone number first.");
        }
    }

    private void requestSmsPermission() {
        // Asks the Android OS to show the Allow/Deny popup
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE
        );
    }

    private boolean hasSmsPermission() {
        // Checks if the user has already granted permission in the past
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateStatus() {
        // Simple UI update helper
        if (hasSmsPermission()) {
            statusText.setText("Status: SMS Permission GRANTED.");
        } else {
            statusText.setText("Status: SMS Permission NOT GRANTED.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // This runs automatically after the user clicks 'Allow' or 'Deny' on the system popup
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                statusText.setText("Permission granted! SMS notifications enabled.");
            } else {
                statusText.setText("Permission denied. App will run without SMS.");
            }
        }
    }
}
