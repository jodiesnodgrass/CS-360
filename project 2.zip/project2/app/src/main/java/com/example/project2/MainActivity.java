package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.project2.database.AppDatabase;
import com.example.project2.database.User;


public class MainActivity extends AppCompatActivity {

    // UI component declarations
    private EditText emailField, passwordField;
    private Button loginButton, createButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the Room Database instance (The "Shell")
        db = AppDatabase.getInstance(this);

        // Bind UI components to XML IDs
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createButton = findViewById(R.id.createButton);

        // Set listener for the Login process
        loginButton.setOnClickListener(v -> {
            attemptLogin();
        });

        // Set listener to navigate to the Registration screen
        createButton.setOnClickListener(v -> {
            // Intent to move from Login screen to RegisterActivity
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    /**
     * Logic to validate user input and verify credentials against the database.
     */
    private void attemptLogin() {
        // Capture user input and trim whitespace
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        // Check if fields are empty using TextUtils utility class
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // DATABASE READ: Check if a user with these credentials exists in the 'users' table
        User authenticatedUser = db.appDao().login(email, password);

        if (authenticatedUser != null) {
            // If user found navigate to the Weight Tracking screen
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, WeightTracker.class);
            startActivity(intent);
            finish(); // Close MainActivity so user can't "back" into login
        } else {
            // If no match is found, notify the user
            Toast.makeText(this, "Invalid credentials. Please try again or create an account.", Toast.LENGTH_LONG).show();
        }
    }
}