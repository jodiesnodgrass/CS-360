package com.example.project2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.project2.database.AppDatabase;
import com.example.project2.database.WeightEntry;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * WeightTracker handles the data grid (CRUD operations) and SMS notification logic.
 */
public class WeightTracker extends AppCompatActivity {

    private TableLayout weightTable;
    private EditText weightInput, goalWeightInput;
    private Button saveButton, settingsButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracker);

        // Initialize database and UI components
        db = AppDatabase.getInstance(this);
        weightTable = findViewById(R.id.weightTable);
        weightInput = findViewById(R.id.weightInput);
        goalWeightInput = findViewById(R.id.goalWeightInput);
        saveButton = findViewById(R.id.saveButton);
        settingsButton = findViewById(R.id.settingsButton);

        // READ: Load existing data into the grid upon opening
        refreshGrid();

        // CREATE: Logic to save a new entry
        saveButton.setOnClickListener(v -> {
            saveWeightEntry();
        });

        // Navigate to SMS Permission settings
        settingsButton.setOnClickListener(v -> {
            startActivity(new Intent(this, SMSPermission.class));
        });
    }




    private void refreshGrid() {
        weightTable.removeAllViews();

        List<WeightEntry> entries = db.appDao().getAllWeights();

        for (WeightEntry entry : entries) {
            TableRow row = new TableRow(this);
            row.setPadding(0, 10, 0, 10);

            // Column 1: Date
            TextView dateTv = new TextView(this);
            dateTv.setText(entry.date);

            // Column 2: Current Weight
            TextView weightTv = new TextView(this);
            weightTv.setText(String.valueOf(entry.currentWeight));
            // Clicking the weight allows the user to increment
            weightTv.setOnClickListener(v -> {
                entry.currentWeight += 0.5;
                db.appDao().updateWeight(entry);
                refreshGrid();
                Toast.makeText(this, "Weight updated", Toast.LENGTH_SHORT).show();
            });

            // Column 3: Goal Weight ---
            TextView goalTv = new TextView(this);
            goalTv.setText(String.valueOf(entry.goalWeight));
            goalTv.setPadding(10, 0, 10, 0);

            // Column 4: Delete Button
            Button deleteBtn = new Button(this);
            deleteBtn.setText("X");
            deleteBtn.setPadding(10, 0, 10, 0);
            deleteBtn.setOnClickListener(v -> {
                db.appDao().deleteWeight(entry);
                refreshGrid();
            });

            // Add all 4 columns to the row in order
            row.addView(dateTv);
            row.addView(weightTv);
            row.addView(goalTv);
            row.addView(deleteBtn);

            weightTable.addView(row);
        }
    }



    /**
     * CREATE: Adds a new weight record and triggers the SMS check.
     */
    private void saveWeightEntry() {
        String wStr = weightInput.getText().toString();
        String gStr = goalWeightInput.getText().toString();

        if (!wStr.isEmpty() && !gStr.isEmpty()) {
            double weight = Double.parseDouble(wStr);
            double goal = Double.parseDouble(gStr);
            String date = new SimpleDateFormat("MM/dd", Locale.getDefault()).format(new Date());

            // Save to Database
            WeightEntry newEntry = new WeightEntry(weight, goal, date);
            db.appDao().insertWeight(newEntry);

            // Check if goal is met and handle SMS notification
            checkGoalAndNotify(weight, goal);

            // Refresh the grid to show new data
            refreshGrid();
            weightInput.setText("");
        }
    }

    /**
     * NOTIFICATION LOGIC: Functions with or without SMS permissions.
     */
    private void checkGoalAndNotify(double current, double goal) {
        if (current <= goal) {
            // Check if user granted SMS permission
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                try {
                    // Logic for when permission is GRANTED
                    SmsManager sms = getSystemService(SmsManager.class);
                    if (sms != null) {
                        // sms.sendTextMessage("5551234", null, "Goal weight met!", null, null);
                        Toast.makeText(this, "Goal Met! SMS sent.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                // Logic for when permission is DENIED (App continues to function)
                Toast.makeText(this, "Goal Met! (SMS not sent: Permission Denied)", Toast.LENGTH_LONG).show();
            }
        }
    }
}
