package com.example.project2.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// This annotation tells Room to create a table named "users"
@Entity(tableName = "users")
public class User {
    @PrimaryKey(autoGenerate = true)
    public int id; // Unique ID for each user

    public String username;
    public String password;

    // The constructor used to create a new user object
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}
