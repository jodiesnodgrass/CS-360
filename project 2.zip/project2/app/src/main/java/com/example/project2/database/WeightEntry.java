package com.example.project2.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// This table stores the actual tracking data
@Entity(tableName = "weight_entries")
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public double currentWeight;
    public double goalWeight;
    public String date;

    public WeightEntry(double currentWeight, double goalWeight, String date) {
        this.currentWeight = currentWeight;
        this.goalWeight = goalWeight;
        this.date = date;
    }
}